# Sales & Revenue Analysis Dashboard

## Objective
Build a dashboard to analyze sales and revenue data, track KPIs, identify top-performing products, and generate business insights.

## Tools
- Microsoft Excel
- CSV
- Pivot/summary analysis
- Excel charts

## Dataset
The dataset contains 300 sales transactions with:
- Order ID
- Order Date
- Product
- Category
- Region
- Quantity
- Unit Price
- Revenue

## KPIs
- Total Revenue: ₹24,519,220
- Total Orders: 300
- Units Sold: 1,026
- Average Order Value: ₹81,731

## Dashboard Features
- KPI cards
- Monthly revenue trend
- Top products by revenue
- Regional analysis
- Category analysis
- Filterable source data

## Key Results
- Top product: Laptop Pro 14
- Top region: South
- Top category: Electronics
- Highest revenue month: 2025-10

## Files
- `Dataset/sales_data.csv` — source dataset
- `Dashboard/Sales_Revenue_Dashboard.xlsx` — completed Excel dashboard
- `Results/business_insights.txt` — project results
- `Screenshots/` — add dashboard screenshots after opening the workbook

## How to Use
1. Open `Sales_Revenue_Dashboard.xlsx`.
2. Open the Dashboard sheet.
3. Review KPI cards and charts.
4. Use the Sales Data sheet filters for interactive analysis.
5. Add screenshots of the dashboard to the Screenshots folder.

## Conclusion
This project demonstrates data cleaning, KPI tracking, aggregation, visualization, and business insight generation using historical sales data.
